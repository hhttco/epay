<?php
if(!defined('IN_PLUGIN'))exit();

echo "<script>window.location.href='/pay/vpay/order/{$trade_no}/?sitename={$sitename}';</script>";

